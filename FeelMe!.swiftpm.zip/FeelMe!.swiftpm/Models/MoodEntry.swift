//
//  MoodEntry.swift
//  FeelMe!
//
//  Created by Steve on 22/02/25.
//

import Foundation
import NaturalLanguage

struct MoodEntry: Identifiable, Codable, Sendable {
    let id: UUID
    let date: Date
    let mood: Mood
    let journalEntry: String
    var sentimentScore: Double
    
    init(id: UUID = UUID(), date: Date = Date(), mood: Mood, journalEntry: String, sentimentScore: Double? = nil) {
        self.id = id
        self.date = date
        self.mood = mood
        self.journalEntry = journalEntry
        self.sentimentScore = sentimentScore ?? Self.analyzeSentiment(journalEntry)
    }
    
    static func analyzeSentiment(_ text: String) -> Double {
        let tagger = NLTagger(tagSchemes: [.sentimentScore])
        tagger.string = text
        
        let (sentiment, _) = tagger.tag(at: text.startIndex, unit: .paragraph, scheme: .sentimentScore)
        
        if let sentimentRawValue = sentiment?.rawValue, let score = Double(sentimentRawValue) {
            return max(-1.0, min(score, 1.0))
        }
        return 0.0
    }
}
