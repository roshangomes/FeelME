import SwiftUI

struct StatsView: View {
    @EnvironmentObject var viewModel: MoodViewModel // ✅ Use shared instance
    @State private var currentMonth: Date = Date() // ✅ Track selected month

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) { // ✅ Left-aligned layout
                    
                    // **Weekly Overview**
                    Text("Weekly Overview 📈")
                        .font(.headline)
                        .padding(.leading, 12) // ✅ Left align title

                    if viewModel.moodEntries.isEmpty {
                        Text("No mood data available yet.")
                            .foregroundColor(.gray)
                            .font(.subheadline)
                            .padding(.horizontal, 12)
                    } else {
                        VStack(alignment: .leading) {
                            LineGraph(moodEntries: viewModel.getWeeklyEntries()) // ✅ Auto-updating
                                .frame(height: 250)
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color(.systemBackground))
                        .cornerRadius(12)
                        .shadow(radius: 2)
                        .padding(.horizontal, 12)
                    }

                    // **Calendar View**
                    Text("Monthly Mood Calendar 📅")
                        .font(.headline)
                        .padding(.leading, 12) // ✅ Left align title

                    VStack {
                        // **Month Selector**
                        HStack {
                            Button(action: { changeMonth(by: -1) }) {
                                Image(systemName: "chevron.left")
                                    .font(.title2)
                                    .foregroundColor(.blue)
                            }
                            Spacer()
                            Text(formatMonth(currentMonth))
                                .font(.title2)
                                .fontWeight(.bold)
                            Spacer()
                            Button(action: { changeMonth(by: 1) }) {
                                Image(systemName: "chevron.right")
                                    .font(.title2)
                                    .foregroundColor(.blue)
                            }
                        }
                        .padding(.horizontal, 20)
                        .padding(.top, 10)

                        if viewModel.getMonthlyEntries().isEmpty {
                            Text("No mood data recorded for this month.")
                                .foregroundColor(.gray)
                                .font(.subheadline)
                                .padding(.horizontal, 12)
                        } else {
                            CalendarView(moodEntries: viewModel.getMonthlyEntries(), selectedMonth: currentMonth) // ✅ Live updates
                                .frame(height: 200)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color(.systemBackground))
                    .cornerRadius(12)
                    .shadow(radius: 2)
                    .padding(.horizontal, 12)

                    Spacer()
                }
                .padding(.horizontal, 12)
                .padding(.bottom, 20)
            }
            .background(Color(hex: "#f2efe4"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    Text("Stats")
                        .font(.headline)
                        .foregroundColor(.black)
                }
            }
            .onAppear {
                Task {
                    await viewModel.loadEntries() // ✅ Auto-refresh data
                }
            }
        }
    }

    // **Change Month Function**
    private func changeMonth(by value: Int) {
        if let newMonth = Calendar.current.date(byAdding: .month, value: value, to: currentMonth) {
            currentMonth = newMonth
        }
    }

    // **Format Month Display**
    private func formatMonth(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMMM yyyy"
        return formatter.string(from: date)
    }
}
