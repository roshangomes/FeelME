import SwiftUI

struct MoodButton: View {
    let mood: Mood
    @Binding var selectedMood: Mood?
    
    var body: some View {
        Button(action: {
            selectedMood = mood
        }) {
            VStack {
                Text(mood.emoji)
                    .font(.system(size: 30))
                Text(mood.rawValue)
                    .font(.caption)
                    .foregroundColor(.primary)
            }
            .frame(width: 70, height: 70)
            .background(selectedMood == mood ? mood.color.opacity(0.2) : Color(.systemGray6))
            .cornerRadius(10)
            .overlay(
                RoundedRectangle(cornerRadius: 10)
                    .stroke(selectedMood == mood ? mood.color : Color.clear, lineWidth: 2)
            )
        }
    }
}
