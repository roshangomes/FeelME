import SwiftUICore
import SwiftUI

struct MoodEntryView: View {
    @Environment(\.dismiss) var dismiss
    @ObservedObject var viewModel: MoodViewModel
    @State private var selectedMood: Mood?
    @State private var journalEntry = ""
    @State private var sentimentScore: Double = 0.0
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 24) {
                    Text("How are you feeling today?")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .padding(.top, 8)
                    
                    // Mood Selection
                    // Mood Selection
                    HStack(spacing: 8) {
                        ForEach([Mood.angry, Mood.sad, Mood.neutral, Mood.happy, Mood.overjoyed], id: \.self) { mood in
                            MoodButton(mood: mood, selectedMood: $selectedMood)
                        }
                    }
                    .padding(.horizontal, 8)

                    
                    // Journal Entry
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Add a note about your day")
                            .font(.headline)
                        
                        TextEditor(text: $journalEntry)
                            .frame(height: 150)
                            .padding(8)
                            .background(Color(.systemGray6))
                            .cornerRadius(12)
                            .onChange(of: journalEntry) { newValue in
                                                            // Update sentiment score in real-time
                                                            sentimentScore = MoodEntry.analyzeSentiment(newValue)
                                                        }
                    }
                    .padding(.horizontal)
                    
                    // Sentiment Score
                                       Text("Sentiment Score: \(String(format: "%.2f", sentimentScore))")
                                           .font(.subheadline)
                                           .foregroundColor(sentimentScore >= 0 ? .green : .red)
                                           .opacity(journalEntry.isEmpty ? 0 : 1)
                                           .animation(.easeInOut, value: journalEntry.isEmpty)
                                       
                                       Spacer()
                }
            }
            .navigationTitle("New Entry")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Save") {
                        if let mood = selectedMood {
                            Task {
                                sentimentScore = MoodEntry.analyzeSentiment(journalEntry)
                                let newEntry = MoodEntry(mood: mood, journalEntry: journalEntry, sentimentScore: sentimentScore)
                                await viewModel.addEntry(newEntry)
                                dismiss()
                            }
                        }
                    }
                    .disabled(selectedMood == nil)
                }
            }
        }
    }
}
