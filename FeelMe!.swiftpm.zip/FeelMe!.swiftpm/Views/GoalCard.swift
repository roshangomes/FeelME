//
//  GoalCard.swift
//  FeelMe!
//
//  Created by Steve on 22/02/25.
//

import SwiftUI

struct GoalCard: View {
    let goal: String
    var body: some View {
        HStack {
            Image(systemName: "target")
                .font(.title2)
                .foregroundColor(.blue)
            
            Text(goal)
                .font(.headline)
            
            Spacer()
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .shadow(radius: 2)
    }
}
