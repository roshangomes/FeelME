import SwiftUI

// MARK: - ViewModel for Managing Mood Entries
@MainActor
class MoodViewModel: ObservableObject {
    @Published var moodEntries: [MoodEntry] = []
    @Published var currentGoal: String? // ✅ Add this property
    
    init() {
        Task {
            await loadEntries()
            updateGoal() // ✅ Update goal on startup
        }
    }

    // MARK: - Load Entries from JSON
    func loadEntries() async {
        moodEntries = await PersistenceController.shared.getEntries()
    }

    // ✅ Save Data to JSON
        func saveData() async {
            await PersistenceController.shared.saveToFile() // Ensure data is written to the file
        }
    
    // MARK: - Add a New Mood Entry
    func addEntry(_ entry: MoodEntry) async {
        DispatchQueue.main.async { [self] in
            self.moodEntries.append(entry) // ✅ Add new entry immediately
            self.updateGoal() // ✅ Update goal
        }
        await PersistenceController.shared.addEntry(mood: entry.mood, journalEntry: entry.journalEntry)
        await saveData() // ✅ Save to JSON
    }

    // MARK: - Delete an Entry
    func deleteEntry(_ entry: MoodEntry) async {
        DispatchQueue.main.async { [self] in
            self.moodEntries.removeAll { $0.id == entry.id } // ✅ Remove from local array first
            self.updateGoal() // ✅ Update goal after deleting
        }
        await PersistenceController.shared.deleteEntry(id: entry.id)
        await saveData() // ✅ Save changes to JSON
    }


    
    // ✅ Function to update the goal based on recent moods
        private func updateGoal() {
            let recentMoods = moodEntries.suffix(4).map { $0.mood }
            if recentMoods.filter({ $0 == .sad }).count >= 3 {
                currentGoal = "Try to find one positive thing each day"
            } else {
                currentGoal = "Stay happy for 4 days!"
            }
        }
    
    // MARK: - Get Mood Entries for a Specific Date
    func getEntries(for date: Date) -> [MoodEntry] {
        let calendar = Calendar.current
        return moodEntries.filter { calendar.isDate($0.date, inSameDayAs: date) }
    }

    // MARK: - Get Weekly Moods (Last 7 Days)
    func getWeeklyEntries() -> [MoodEntry] {
        let calendar = Calendar.current
        let sevenDaysAgo = calendar.date(byAdding: .day, value: -7, to: Date()) ?? Date()
        return moodEntries.filter { $0.date >= sevenDaysAgo }
    }

    // MARK: - Get Monthly Moods (For Calendar View)
    func getMonthlyEntries() -> [MoodEntry] {
        let calendar = Calendar.current
        let startOfMonth = calendar.dateInterval(of: .month, for: Date())?.start ?? Date()
        return moodEntries.filter { $0.date >= startOfMonth }
    }

    // MARK: - Get Current Mood Streak (Consecutive Same Moods)
    func getCurrentMoodStreak() -> Int {
        guard !moodEntries.isEmpty else { return 0 }
        
        var streak = 1
        let sortedEntries = moodEntries.sorted { $0.date > $1.date }
        
        for i in 1..<sortedEntries.count {
            if sortedEntries[i].mood == sortedEntries[i - 1].mood {
                streak += 1
            } else {
                break
            }
        }
        return streak
    }
}
