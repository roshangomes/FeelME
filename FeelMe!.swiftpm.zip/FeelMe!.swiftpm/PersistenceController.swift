import Foundation

actor PersistenceController {
    static let shared = PersistenceController()
    private let fileName = "moodEntries.json"

    private var entries: [MoodEntry] = []

    // MARK: - File Path for JSON Storage
    private var fileURL: URL {
        let urls = FileManager.default.urls(for: .libraryDirectory, in: .userDomainMask)
        return urls[0].appendingPathComponent(fileName)
    }


    // MARK: - Save Data to JSON File
    public func saveToFile() {
        do {
            let directory = fileURL.deletingLastPathComponent()
            if !FileManager.default.fileExists(atPath: directory.path) {
                try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true, attributes: nil)
            }

            let data = try JSONEncoder().encode(entries)
            try data.write(to: fileURL, options: [.atomic, .completeFileProtection])
            print("✅ Mood entries saved successfully to: \(fileURL.path)")
        } catch {
            print("❌ Failed to save mood entries: \(error.localizedDescription)")
        }
    }

    // MARK: - Load Data from JSON File
    func loadEntries() {
        do {
            let data = try Data(contentsOf: fileURL)
            entries = try JSONDecoder().decode([MoodEntry].self, from: data)
            print("✅ Loaded \(entries.count) mood entries from: \(fileURL.path)")
        } catch {
            print("⚠️ No previous data found, starting fresh.")
            entries = []
        }
    }


    // MARK: - Add New Mood Entry
    func addEntry(mood: Mood, journalEntry: String) {
        let newEntry = MoodEntry(mood: mood, journalEntry: journalEntry)
        entries.append(newEntry)
        saveToFile() // ✅ Save after adding an entry
    }

    // MARK: - Get All Entries
    func getEntries() -> [MoodEntry] {
        return entries
    }

    // MARK: - Delete an Entry
    func deleteEntry(id: UUID) {
        entries.removeAll { $0.id == id }
        saveToFile() // ✅ Save after deletion
    }
}
