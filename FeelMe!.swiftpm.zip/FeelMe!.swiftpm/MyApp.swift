import SwiftUI
import NaturalLanguage
import Charts

@main
struct MyApp: App {
    @StateObject var viewModel = MoodViewModel() // Initialize ViewModel

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(viewModel)
                .onReceive(NotificationCenter.default.publisher(for: UIApplication.willTerminateNotification)) { _ in
                    Task {#imageLiteral(resourceName: "Screenshot 2025-02-24 at 12.01.15 AM.png")
                        await viewModel.saveData() // ✅ Force-save data when the app is terminated
                    }
                    
                }
        }
    }
}
