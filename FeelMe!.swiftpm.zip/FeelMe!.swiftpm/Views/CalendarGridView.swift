import SwiftUI

struct CalendarGridView: View {
    let moodEntries: [MoodEntry]
    let selectedMonth: Date
    
    private let columns = Array(repeating: GridItem(.flexible(), spacing: 8), count: 7)
    private let weekDays = ["S", "M", "T", "W", "T", "F", "S"]
    
    var body: some View {
        VStack(spacing: 8) {
            // **Weekday Labels**
            HStack(spacing: 0) {
                ForEach(weekDays, id: \.self) { day in
                    Text(day)
                        .font(.caption2)
                        .frame(maxWidth: .infinity)
                        .foregroundColor(.gray)
                }
            }
            
            // **Calendar Grid**
            LazyVGrid(columns: columns, spacing: 8) {
                ForEach(getDaysInMonth(), id: \.self) { date in
                    let moodsForDay = moodEntries.filter { Calendar.current.isDate($0.date, inSameDayAs: date) }
                    
                    // ✅ Compute Average Sentiment Score
                    let totalSentiment = moodsForDay.reduce(0.0) { $0 + $1.sentimentScore }
                    let averageSentiment = moodsForDay.isEmpty ? 0 : totalSentiment / Double(moodsForDay.count)

                    Text("\(Calendar.current.component(.day, from: date))")
                        .font(.caption)
                        .frame(height: 32)
                        .frame(maxWidth: .infinity)
                        .background(getMoodColor(for: averageSentiment).opacity(0.3)) // ✅ Use cumulative mood color
                        .cornerRadius(8)
                }
            }
        }
        .padding(.horizontal)
    }
    
    // ✅ Get All Days in the Selected Month
    private func getDaysInMonth() -> [Date] {
        let calendar = Calendar.current
        let month = calendar.component(.month, from: selectedMonth)
        let year = calendar.component(.year, from: selectedMonth)
        
        guard let firstDay = calendar.date(from: DateComponents(year: year, month: month, day: 1)),
              let range = calendar.range(of: .day, in: .month, for: firstDay) else {
            return []
        }
        
        return range.compactMap { day in
            calendar.date(byAdding: .day, value: day - 1, to: firstDay)
        }
    }

    // ✅ Assign Color Based on Cumulative Sentiment Score
    private func getMoodColor(for sentimentScore: Double) -> Color {
        switch sentimentScore {
        case let x where x > 0.5:
            return Color.green // ✅ Very Positive Mood
        case let x where x > 0:
            return Color.blue // ✅ Slightly Positive Mood
        case let x where x < -0.5:
            return Color.orange // ✅ Very Negative Mood
        case let x where x < 0:
            return Color.red // ✅ Slightly Negative Mood
        default:
            return Color.gray.opacity(0.5) // ✅ Neutral / No Data
        }
    }
}
