//
//  CalendarView.swift
//  FeelMe!
//
//  Created by Steve on 22/02/25.
//

import SwiftUI

struct CalendarView: View {
    let moodEntries: [MoodEntry]
    let selectedMonth: Date

    var body: some View {
        VStack {
            CalendarGridView(moodEntries: filteredEntries(), selectedMonth: selectedMonth) // ✅ Use filtered entries
                .padding()
        }
    }

    // **Filter Mood Entries for Selected Month**
    private func filteredEntries() -> [MoodEntry] {
        let calendar = Calendar.current
        return moodEntries.filter {
            calendar.isDate($0.date, equalTo: selectedMonth, toGranularity: .month)
        }
    }
}
