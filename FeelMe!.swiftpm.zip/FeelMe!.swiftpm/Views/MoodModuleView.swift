//
//  MoodModuleView.swift
//  FeelMe!
//
//  Created by Steve on 23/02/25.
//

import SwiftUI

struct MoodModuleView: View {
    let moodEntry: MoodEntry
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(moodEntry.mood.emoji)
                    .font(.largeTitle)
                
                VStack(alignment: .leading) {
                    Text(moodEntry.mood.rawValue.capitalized)
                        .font(.headline)
                        .fontWeight(.bold)
                    
                    Text(formatTime(moodEntry.date)) // Using custom formatter
                        .font(.caption)
                        .foregroundColor(.gray)
                }
                Spacer()
            }
            
            Text(moodEntry.journalEntry)
                .font(.body)
                .foregroundColor(.primary)
                .multilineTextAlignment(.leading)
                .lineLimit(3)
                
            Spacer()
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .shadow(radius: 2)
    }
    
    // **Moved the function outside the body**
    private func formatTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm" // 24-hour format
        return formatter.string(from: date)
    }
}
