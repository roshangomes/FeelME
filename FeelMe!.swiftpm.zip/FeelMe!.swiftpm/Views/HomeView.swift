import SwiftUI

struct HomeView: View {
    @EnvironmentObject var viewModel: MoodViewModel // ✅ Use shared instance
    @State private var userName: String = UserDefaults.standard.string(forKey: "userName") ?? "User" // ✅ Fetch stored name

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {

                    // **Header with Date & Greeting**
                    HStack {
                        Text("Hey, ")
                            .font(.system(size: 20))
                            .foregroundColor(.black)
                        +
                        Text("\(userName)! 👋")
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.black)

                        Spacer()

                        // **Date Display**
                        HStack {
                            Image(systemName: "calendar")
                                .foregroundColor(.purple)
                                .font(.system(size: 14))

                            Text(currentDateFormatted())
                                .font(.system(size: 14, weight: .semibold))
                        }
                        .padding(.horizontal, 10)
                        .padding(.vertical, 12)
                        .background(Color.white)
                        .cornerRadius(16)
                        .shadow(radius: 1)
                    }
                    .padding(.horizontal)

                    // **Today's Mood Chart Title**
                    Text("Today's Mood Chart 📊")
                        .font(.headline)
                        .padding(.leading)

                    // **Mood Chart Section**
                    VStack(alignment: .leading, spacing: 10) {
                        MoodChartView(moodEntries: viewModel.getEntries(for: Date())) // ✅ Auto-refresh
                    }
                    .padding(12)
                    .background(Color.white)
                    .cornerRadius(12)
                    .shadow(radius: 2)
                    .padding(.horizontal, 12)

                    // **Today's Entries Title**
                    Text("Today's Entries 📝")
                        .font(.headline)
                        .padding(.leading)

                    // **Mood Entries List**
                    if viewModel.getEntries(for: Date()).isEmpty {
                        Text("No mood entries recorded today.")
                            .foregroundColor(.gray)
                            .font(.subheadline)
                            .padding()
                    } else {
                        ForEach(viewModel.getEntries(for: Date())) { entry in
                            MoodModuleView(moodEntry: entry)
                                .padding(.horizontal, 12)
                        }
                    }

                    Spacer()
                }
                .padding(.horizontal)
            }
            .background(Color(hex: "#f2efe4"))
            .navigationBarHidden(true)
            .onAppear {
                Task {
                    await viewModel.loadEntries() // ✅ Refresh data on appear
                }
            }
        }
       
    }
    

    // **Format Current Date**
    private func currentDateFormatted() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "E, d MMM"
        return formatter.string(from: Date())
    }
}
