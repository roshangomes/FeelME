import SwiftUI

struct MoodChartView: View {
    let moodEntries: [MoodEntry]
    let maxBarHeight: CGFloat = 120
    let totalBars = 6 // Ensure bars always appear

    var body: some View {
        HStack(spacing: 30) {
            ForEach(0..<totalBars, id: \ .self) { index in
                VStack (spacing:5){
                    // Emoji placed at the top of the bar
                    Text(findMoodEmoji(for: index))
                        .font(.title)
                        .opacity(moodEntries.indices.contains(index) ? 1.0 : 0.3)

                    ZStack(alignment: .bottom) {
                        RoundedRectangle(cornerRadius: 8)
                            .frame(width: 30, height: maxBarHeight)
                            .foregroundColor(Color.gray.opacity(0.2)) // ✅ Always visible background bar

                        if moodEntries.indices.contains(index) {
                            RoundedRectangle(cornerRadius: 8)
                                .frame(width: 30, height: moodHeight(moodEntries[index].sentimentScore))
                                .foregroundColor(moodColor(moodEntries[index].mood))
                        } else {
                            RoundedRectangle(cornerRadius: 8)
                                .frame(width: 30, height: maxBarHeight * 0.3) // ✅ Placeholder height
                                .foregroundColor(Color.gray.opacity(0.3))
                        }
                    }

                    // Display time of entry or placeholder
                    Text(moodEntries.indices.contains(index) ? formattedTime(moodEntries[index].date) : "--:--")
                                    .font(.caption2)
                                    
                                    
                                    .minimumScaleFactor(0.8)
                                    .foregroundColor(.gray.opacity(moodEntries.indices.contains(index) ? 1.0 : 0.5))
                }
            }
        }
        .padding(.horizontal,10)
    }

    // Sort mood entries by time (earliest first)
    private func sortedMoodEntries() -> [MoodEntry] {
        return moodEntries.sorted { $0.date < $1.date }
    }

    // ✅ Dynamic bar height based on sentiment score
    private func moodHeight(_ sentimentScore: Double) -> CGFloat {
        let minHeight: CGFloat = 30  // Minimum bar height
        let maxHeight: CGFloat = 120 // Maximum bar height

        // Normalize sentiment score (-1 to 1) to fit bar height range
        let normalizedHeight = (sentimentScore + 1) / 2 * (maxHeight - minHeight) + minHeight
        return max(minHeight, min(normalizedHeight, maxHeight)) // Ensure it stays in range
    }

    // ✅ Assign colors based on mood type
    private func moodColor(_ mood: Mood) -> Color {
        switch mood {
        case .happy: return Color.blue
        case .neutral: return Color("beige")
        case .sad: return Color.orange
        case .overjoyed: return Color.green
        case .angry: return Color.red
        }
    }

    // ✅ Get emoji for mood entry or placeholder
    private func findMoodEmoji(for index: Int) -> String {
        return moodEntries.indices.contains(index) ? moodEntries[index].mood.emoji : "🙂"
    }

    // ✅ Format time for mood entry or placeholder
    private func formattedTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
}
