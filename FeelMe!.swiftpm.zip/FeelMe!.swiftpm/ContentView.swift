import SwiftUI

struct ContentView: View {
    @AppStorage("hasSeenOnboarding") private var hasSeenOnboarding: Bool = false
    @State private var showingMoodEntry = false
    @StateObject private var viewModel = MoodViewModel()

    init() {
        customizeTabBarAppearance()
    }

    var body: some View {
        ZStack {
            
            
            if hasSeenOnboarding {
                // ✅ Show main app after onboarding is completed
                TabView {
                    HomeView()
                        .environmentObject(viewModel)
                        .tabItem {
                            Label("Home", systemImage: "house.fill")
                        }

                    StatsView()
                        .environmentObject(viewModel)
                        .tabItem {
                            Label("Stats", systemImage: "chart.bar.fill")
                        }
                }

                // **Floating + Button**
                VStack {
                    Spacer()
                    Button(action: { showingMoodEntry = true }) {
                        Image(systemName: "plus")
                            .font(.system(size: 28, weight: .bold))
                            .foregroundColor(.white)
                            .frame(width: 55, height: 55)
                            .background(Color.brown)
                            .clipShape(Circle())
                            .shadow(radius: 3)
                    }
                    .padding(.bottom, 10)
                }
            } else {
                // ✅ Show onboarding screen first
                OnboardingView(hasCompletedOnboarding: $hasSeenOnboarding)
            }
        }
        .sheet(isPresented: $showingMoodEntry) {
            MoodEntryView(viewModel: viewModel)
        }
    }

    // **Apply Tab Bar Appearance**
    private func customizeTabBarAppearance() {
        let appearance = UITabBarAppearance()
        appearance.configureWithOpaqueBackground()
        appearance.backgroundColor = UIColor.systemBackground.withAlphaComponent(0.9)
        
        UITabBar.appearance().isTranslucent = true
        UITabBar.appearance().standardAppearance = appearance
        UITabBar.appearance().scrollEdgeAppearance = appearance
    }
}
