import SwiftUI

struct OnboardingView: View {
    @Binding var hasCompletedOnboarding: Bool
    @State private var userName: String = ""
    @FocusState private var isNameFieldFocused: Bool
    @State private var isAnimating: Bool = false
    
    var body: some View {
        GeometryReader { geometry in
            ScrollView {
                VStack(spacing: 40) {
                    Spacer()
                        .frame(height: geometry.size.height * 0.05)
                    
                    // App Icon with animation
                    Image(systemName: "heart.text.square.fill")
                        .font(.system(size: 100))
                        .foregroundStyle(.linearGradient(
                            colors: [.blue, .blue.opacity(0.8)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ))
                        .scaleEffect(isAnimating ? 1.1 : 1.0)
                        .shadow(color: .blue.opacity(0.3), radius: 10, x: 0, y: 5)
                        .onAppear {
                            withAnimation(.easeInOut(duration: 1.0).repeatForever(autoreverses: true)) {
                                isAnimating = true
                            }
                        }
                        .padding(.top, -20)
                    
                    // Welcome Text Section
                    VStack(spacing: 12) {
                        Text("Welcome to FeelMe!")
                            .font(.system(size: 32, weight: .bold))
                            .foregroundStyle(.primary)
                        
                        Text("Track your moods & improve well-being")
                            .font(.title3)
                            .foregroundStyle(.secondary)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 24)
                    }
                    
                    // Name Input Section
                    VStack(spacing: 16) {
                        Text("Enter your name")
                            .font(.headline)
                            .foregroundStyle(.primary)
                        
                        TextField("Your Name", text: $userName)
                            .textContentType(.name)
                            .focused($isNameFieldFocused)
                            .font(.body)
                            .padding()
                            .frame(maxWidth: 300)
                            .background {
                                RoundedRectangle(cornerRadius: 16, style: .continuous)
                                    .fill(Color(.systemGray6))
                            }
                            .overlay {
                                RoundedRectangle(cornerRadius: 16, style: .continuous)
                                    .stroke(isNameFieldFocused ? .blue : .clear, lineWidth: 1)
                            }
                            .multilineTextAlignment(.center)
                            .autocorrectionDisabled()
                            .textInputAutocapitalization(.words)
                    }
                }
                .frame(minHeight: geometry.size.height)
            }
            .scrollDismissesKeyboard(.immediately)
            .safeAreaInset(edge: .bottom) {
                // Get Started Button
                Button(action: {
                    withAnimation(.spring()) {
                        UserDefaults.standard.set(userName, forKey: "userName")
                        hasCompletedOnboarding = true
                        UserDefaults.standard.set(true, forKey: "hasSeenOnboarding")
                    }
                }) {
                    Text("Get Started")
                        .font(.headline)
                        .foregroundStyle(.white)
                        .frame(height: 56)
                        .frame(maxWidth: 300)
                        .background {
                            RoundedRectangle(cornerRadius: 28, style: .continuous)
                                .fill(userName.isEmpty ? .gray.opacity(0.5) : .blue)
                        }
                        .contentShape(Rectangle())
                }
                .disabled(userName.isEmpty)
                .padding(.horizontal, 20)
                .padding(.bottom, geometry.safeAreaInsets.bottom > 0 ? 0 : 20)
            }
        }
        .background(Color(hex: "#F5EAE8")) // Apply background color
        .ignoresSafeArea() // Extend color to edges
    }
}

// MARK: - Hex Color Extension
extension Color {
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let r, g, b: Double
        switch hex.count {
        case 6:
            r = Double((int >> 16) & 0xFF) / 255.0
            g = Double((int >> 8) & 0xFF) / 255.0
            b = Double(int & 0xFF) / 255.0
        default:
            r = 1.0; g = 1.0; b = 1.0
        }
        self.init(red: r, green: g, blue: b)
    }
}

#Preview {
    OnboardingView(hasCompletedOnboarding: .constant(false))
}
