//
//  Mood.swift
//  FeelMe!
//
//  Created by Steve on 22/02/25.
//

import SwiftUI

enum Mood: String, CaseIterable, Codable, Sendable {
    case sad = "Sad"
    case neutral = "Neutral"
    case happy = "Happy"
    case overjoyed = "Overjoyed"
    case angry = "Angry" // ✅ New Mood Added
    
    var emoji: String {
        switch self {
        case .angry: return "😠"
        case .sad: return "😞"
        case .neutral: return "😐"
        case .happy: return "😊"
        case .overjoyed: return "😄"
       
        }
    }
    
    var color: Color {
        switch self {
        case .sad: return .orange
        case .angry: return .red // ✅ Angry Mood Color
        case .neutral: return Color("beige") // ✅ Beige Color
        case .happy: return .blue
        case .overjoyed: return .green
        
        }
    }
}
