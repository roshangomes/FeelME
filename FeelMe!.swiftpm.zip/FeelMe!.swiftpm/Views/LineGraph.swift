import SwiftUI

struct LineGraph: View {
    var moodEntries: [MoodEntry]
    
    // Adjusted constants for better space usage
    private let maxBarHeight: CGFloat = 180 // Increased from 150
    private let weekdays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
    
    var body: some View {
        GeometryReader { geometry in
            VStack(spacing: 0) {
                // Legend with better spacing
                HStack(spacing: 20) {
                    HStack(spacing: 8) {
                        Circle()
                            .fill(Color.green.opacity(0.8))
                            .frame(width: 10, height: 10)
                        Text("Positive")
                            .font(.caption)
                            .foregroundColor(.gray)
                    }
                    
                    HStack(spacing: 8) {
                        Circle()
                            .fill(Color.orange.opacity(0.8))
                            .frame(width: 10, height: 10)
                        Text("Negative")
                            .font(.caption)
                            .foregroundColor(.gray)
                    }
                    
                    Spacer()
                }
                .padding(.horizontal)
                .padding(.top, 0)
                
                // Bar Graph with dynamic width calculation
                HStack(alignment: .bottom, spacing: 0) {
                    ForEach(weekdays, id: \.self) { weekday in
                        VStack(spacing: 4) {
                            // Bar with dynamic width
                            RoundedRectangle(cornerRadius: 8)
                                .fill(getBarColor(for: weekday))
                                .frame(width: (geometry.size.width - 32) / CGFloat(weekdays.count) - 8,
                                     height: getBarHeight(for: weekday))
                            
                            // Day Label
                            Text(weekday)
                                .font(.caption2)
                                .foregroundColor(.gray)
                        }
                        if weekday != weekdays.last {
                            Spacer()
                        }
                    }
                }
                .frame(height: maxBarHeight + 20)
                .padding(.horizontal)
                .padding(.top, 16)
                
                Divider()
                    .padding(.horizontal)
                    .padding(.vertical, 8)
                
                // Mood Emojis Row with dynamic width
                HStack(alignment: .center, spacing: 0) {
                    ForEach(weekdays, id: \.self) { weekday in
                        VStack {
                            Text(getEmoji(for: weekday) ?? "○")
                                .font(.system(size: 24))
                        }
                        .frame(width: (geometry.size.width - 32) / CGFloat(weekdays.count))
                    }
                }
                .padding(.horizontal)
                .padding(.bottom, 8)
            }
        }
        .frame(height: 280)
    }
    
    // Updated helper functions to handle multiple entries
    private func getBarColor(for weekday: String) -> Color {
        let entries = findEntries(for: weekday)
        if entries.isEmpty {
            return Color.gray.opacity(0.1)
        }
        
        let averageSentiment = entries.reduce(0.0) { $0 + $1.sentimentScore } / Double(entries.count)
        return averageSentiment >= 0 ? Color.green.opacity(0.8) : Color.orange.opacity(0.8)
    }
    
    private func getBarHeight(for weekday: String) -> CGFloat {
        let entries = findEntries(for: weekday)
        if entries.isEmpty {
            return maxBarHeight * 0.9 // Minimal height for empty days
        }
        
        let averageSentiment = entries.reduce(0.0) { $0 + $1.sentimentScore } / Double(entries.count)
        return maxBarHeight * CGFloat(abs(averageSentiment))
    }
    
    private func getEmoji(for weekday: String) -> String? {
        let entries = findEntries(for: weekday)
        if entries.isEmpty {
            return nil
        }
        
        // Get the most frequent mood for the day
        var moodCounts: [Mood: Int] = [:]
        entries.forEach { entry in
            moodCounts[entry.mood, default: 0] += 1
        }
        
        if let dominantMood = moodCounts.max(by: { $0.value < $1.value })?.key {
            return dominantMood.emoji
        }
        
        return entries.last?.mood.emoji
    }
    
    private func findEntries(for weekday: String) -> [MoodEntry] {
        let calendar = Calendar.current
        let today = Date()
        
        guard let sunday = calendar.date(from: calendar.dateComponents([.yearForWeekOfYear, .weekOfYear], from: today)) else {
            return []
        }
        
        guard let weekdayIndex = weekdays.firstIndex(of: weekday),
              let targetDate = calendar.date(byAdding: .day, value: weekdayIndex, to: sunday) else {
            return []
        }
        
        return moodEntries.filter { entry in
            calendar.isDate(entry.date, inSameDayAs: targetDate)
        }
    }
}
